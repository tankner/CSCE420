from Player import Player
from Game import Action


class MyPlayer(Player):
    # 1. Add your UINs seperated by a ':'
    #    DO NOT USE A COMMA ','
    #    We use CSV files and commas will cause trouble
    # 2. Write your strategy under the play function
    # 3. Add your team's name (this will be visible to your classmates on the leader board)

    UIN = "Your UINs seperated by ':'"

    def play(self, opponent_prev_action):
        # Write your strategy as a function of the opponent's previous action and the error rate for prev action report
        # For example, the below implementation returns the opponent's prev action if the error is smaller than 0.5
        # else it returns the opposite of the opponent's reported action
        # Don't forget to remove the example...

        if opponent_prev_action == Action.Noop:
            return Action.Silent
        if self.error_rate < 0.5:
            return opponent_prev_action
        else:
            return Action(-(opponent_prev_action.value - 1))

    def __str__(self):
        return "Your team name"
